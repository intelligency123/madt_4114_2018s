//
//  ViewController.swift
//  SaveVolume
//
//  Created by robin on 2017-11-08.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //variables
     let defaults = UserDefaults.standard
    
    @IBOutlet weak var volume: UITextField!
    @IBOutlet weak var slidervalue: UILabel!
    @IBOutlet weak var slide: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let x = defaults.float(forKey: "slidevalue")
         volume.text = "\(x)"
        slide.value = x
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func slidervalue(_ sender: UISlider) {
        let val = sender.value
        //slidervalue.text = "\(value)"
        defaults.set(val ,forKey: "slidevalue")
        let x = defaults.float(forKey: "slidevalue")
        print(x)
        volume.text = "\(x)"
    }
}

