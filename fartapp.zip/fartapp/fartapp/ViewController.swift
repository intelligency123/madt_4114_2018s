//
//  ViewController.swift
//  fartapp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    //variables and outlets
    
    
    //sound player variable
    var player : AVAudioPlayer?
    
    //default functions

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //actions
    @IBAction func playFart(_ sender: UIButton) {
       // print("wet fart pressed")
        //1. creating variable represent the file location
         var url = Bundle.main.url(forResource:"fart-squeak-01", withExtension:"mp3")
        if(sender.tag == 1){
            print("wet fart")
             url = Bundle.main.url(forResource:"fart-03", withExtension:"mp3")
            
        }else if(sender.tag == 2){
            print("squeak fart")
              url = Bundle.main.url(forResource:"fart-squeak-01", withExtension:"mp3")
        }else if(sender.tag == 3){
            print("lentil fart")
            url = Bundle.main.url(forResource:"fart-06", withExtension:"mp3")
        }
      
        do{
            //2.tell the audio player location of file
            player = try AVAudioPlayer(contentsOf: url!)
            
            //3. paly the sound
           player?.play()
            //code in here will throw error
            
        }
        catch{
             //4.deal with any error
            print("error while trying to playb file")
        }
        
       
    }
    
    
   
    
}

