//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class ViewController: UIViewController {
    var db:DatabaseReference!
    
    @IBOutlet weak var datatext: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.db = Database.database().reference()
        /*
        self.db.setValue(32453)
        //add some keys
        let x:[String:Any] = ["age":25,"color":"blue"]
        self.db.setValue(x)
        //add a new node
        self.db.child("cars").setValue(55)
        self.db.child("name").setValue("kamal")
        //add node inside another node
        let y:[String:Any] = ["name":"kadeen","dept":"CPCT"]
        self.db.child("instructor").setValue(y)
        self.db.childByAutoId().setValue("hello duniyan")
        self.db.childByAutoId().setValue("apple")
 */
        //tell fb you are interested in knowing whn data changes
        watchforchanges()
        
    
    }
    func watchforchanges(){
        self.db.child("todos").observe(DataEventType.childAdded, with:{
            (snapshot) in
            print("something added in the database")
            let x = snapshot.value
            print(x)
            print("-----")
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func adddata(_ sender: UIButton) {
        print("add data pressed")
        let x = datatext.text!
        if(x.isEmpty == true){
            return
        }
        self.db.child("todos").childByAutoId().setValue(x)
        datatext.text = ""
    }
    
}

