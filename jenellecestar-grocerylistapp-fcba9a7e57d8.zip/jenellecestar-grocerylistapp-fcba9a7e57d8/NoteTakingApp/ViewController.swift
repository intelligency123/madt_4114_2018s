//
//  ViewController.swift
//  NoteTakingApp
//
//  Created by robin on 2018-07-09.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    
    @IBOutlet weak var noteText: UITextField!
    
    var groceryList: [GroceryListItem] = []
   
    @IBOutlet weak var textView: UITextView!
     var manageContext : NSManagedObjectContext?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       //1.crete connection to the database
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
         manageContext = appDelegate.persistentContainer.viewContext
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func addSampleData() {
        for x in 1...5 {
            
            let randomWords = "This is item \(x)"
       
        }
    }

    @IBAction func addNote(_ sender: Any) {
        print("clicked!")
        
        // check if textbox is empty
        guard let x = noteText.text , x != "" else {
            print("textbox is empty")
            return
        }
            //1.create new object
            let itementity = NSEntityDescription.entity(forEntityName: "GroceryItem", in: manageContext!)
             let item = NSManagedObject(entity: itementity!, insertInto: manageContext!)
            //2.set the properties
           item.setValue(noteText.text!, forKey: "itemName")
             item.setValue(Date(), forKey: "dateAdded")
            //3.save the object
            do{
          try  manageContext?.save()
            }
            catch{
                print("error saving to database")
            }
        
        
   
        // clear the textbox
        noteText.text = ""
        
        // create an alert box to show user
        
        // -- make an alert
        let alert = UIAlertController(title: "Save Complete", message: "Your item was saved!", preferredStyle: .alert)
        
        // -- add a button
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
        
        // -- show the popup
        self.present(alert, animated: true, completion: nil)
       
        
    }

    @IBAction func showAll(_ sender: Any) {
        //make fetch request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "GroceryItem")
        //send query to the dataabse
        do{
         let rows = try manageContext!.fetch(fetchRequest)
            for item in rows {
                let x = item as! GroceryItem
                print("\(x.dateAdded!): \(x.itemName!)")
            }
        }
        catch{
            print("unable to fetch")
        }
      
    }
}

