//
//  ViewController.swift
//  relationship
//
//  Created by MacStudent on 2018-07-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
     var managedContext : NSManagedObjectContext?
    
    @IBOutlet weak var notebookname: UITextField!
    
    @IBOutlet weak var pagename: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        managedContext = appDelegate.persistentContainer.viewContext
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func notebookaction(_ sender: UIButton) {
        print("notebook added")
        //validation
        let x = notebookname.text!
        if(x.isEmpty){
            print("please give your notebook name")
            return
        }
        let notebook = Notebook(context: managedContext!)
        notebook.title = notebookname.text!
        notebook.datecreated = Date()
        
        do{
            try managedContext?.save()
        }
        catch{
            print("error saving notebook")
        }
    }
    
    @IBAction func addpage(_ sender: UIButton) {
        let page = Page(context: managedContext!)
        page.text = pagename.text!
        page.dateadded = Date()
         let x = notebookname.text!
        //validation
        if(x.isEmpty){
            print("please give your notebook name")
            return
        }
        let n = getNotebook(name:x)
        //validation
        if(n == nil){
            print("this notebook doesn't exist")
            return
        }
        page.notebooks = n
        
        do{
            try managedContext?.save()
        }
        catch{
            print("error saving page")
        }
    }
    func getNotebook(name:String) -> Notebook?{
        //fetch the notebook
        let fetchRequest:NSFetchRequest<Notebook> = Notebook.fetchRequest()
        //add where statement
        fetchRequest.predicate = NSPredicate(format: "title = %@", name)
        //add limit
        fetchRequest.fetchLimit = 1
        //get result from database
        do{
        let rows =   try managedContext?.fetch(fetchRequest)
            if((rows?.count)! > 0){
                print(rows![0].title)
                return rows?[0]
            }else{
                return nil
            }
            
        }
        catch{
            print("unable to fetch")
        }
        //return it
        return nil
        
    }
    
    @IBAction func showallpages(_ sender: UIButton) {
         let x = notebookname.text!
        //validation
        if(x.isEmpty){
            print("please give your notebook name")
            return
        }
        //let p = getpages(name:x)
          let n = getNotebook(name:x)
        let fetchRequest:NSFetchRequest<Page> = Page.fetchRequest()
        //add where statement
        fetchRequest.predicate = NSPredicate(format: "notebooks = %@", n!)
        //get result from database
        do{
            let rows =   try managedContext?.fetch(fetchRequest)
            for row in rows!{
                print(row.text!)
                print(row.dateadded!)
            }
            
        }
        catch{
            print("unable to fetch")
        }
    }
   
}

