//
//  editViewController.swift
//  relationship
//
//  Created by MacStudent on 2018-07-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData
class editViewController: UIViewController {
    var page:Page!
      var managedContext : NSManagedObjectContext?
    @IBOutlet weak var pagetextview: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        managedContext = appDelegate.persistentContainer.viewContext
        // Do any additional setup after loading the view.
        print(" edit view")
        print("######")
        print(page.text)
        pagetextview.text = page.text
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func updatesave(_ sender: UIButton) {
        let y = pagetextview.text!
        self.page.text = y
        do{
            try managedContext?.save()
        }
        catch{
            print("unable to save")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
