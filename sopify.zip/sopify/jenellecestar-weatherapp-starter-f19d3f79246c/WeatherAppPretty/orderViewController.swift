//
//  orderViewController.swift
//  WeatherAppPretty
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire            // 1. Import AlamoFire and SwiftyJson
import SwiftyJSON

import ChameleonFramework         // optional - used to make colors pretty

import CoreLocation   
class orderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getoder() {
        // Build the URL:
        
        
        let url = "https://shopicruit.myshopify.com/admin/orders.json?page=1&access_token=c32313df0d0ef512ca64d5b336a0d7c6"
        print(url)
        
        
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
            
            (response) in
            
            if response.result.isSuccess {
                if let dataFromServer = response.data {
                    
                    
                    do {
                        let json = try JSON(data: dataFromServer)
                        
                        // TODO: Parse the json response
                       // print(json)
                        
                        // TODO: Display the results
                        let s = json["orders"].arrayValue
                        //let id = s["0"]!.dictionaryValue
                      //- let c = s.count
                        for i in s{
                           // let first = s[i].dictionaryValue
                            let process = i["processed_at"].stringValue
                            let date = i["created_at"].stringValue
                            let orderid = String(describing: i["id"].doubleValue)
                            print("========")
                            print("date: \(date)")
                             print("order id: \(orderid)")
                     
                        
                            let first4 = process.prefix(4)
                            if(first4 == "2017"){
                             
                                let k = i["customer"].dictionaryValue
                                let name = k["first_name"]?.stringValue
                                    print(process)
                                    print(name)
                             
                                    
                                    
                                
                                   
                                }
 
                        }
                        
                       // let first = s[0].dictionaryValue
                        //let m = json["message"].stringValue
                       // let process = first["processed_at"]!.stringValue
                      //  let first4 = process.prefix(4)
                       // let k = first["customer"]!.dictionaryValue
                       // let name = k["first_name"]!.stringValue
                       // print(first4)
                       // print(process)
                       // print(name)
                        //print(m)
                        
                    }
                    catch {
                        print("error")
                    }
                    
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                // 6. You got an error while trying to connect to the API
                print("Error while fetching data from URL")
            }
            
        }
        
        
    }
    
    @IBAction func orderpressed(_ sender: UIButton) {
        getoder()
    }
    
  

}
