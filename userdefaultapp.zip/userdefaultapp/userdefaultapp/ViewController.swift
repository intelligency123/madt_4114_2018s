//
//  ViewController.swift
//  userdefaultapp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //user dafault
        //1.tell ios you want to use userdefault
        let defaults =  UserDefaults.standard
        //show what is in the dictionary
      //  print(defaults.dictionaryRepresentation())
        //2.add some thing to userdefault
        defaults.set("kamal", forKey: "myname")
        //3.print/get stuff from userdefault
       // print(defaults.dictionaryRepresentation())
        //boolean
        defaults.set(true,forKey: "is instructor")
        //double
        defaults.set(800.90, forKey: "hourlyrate")
        //array
        let coursestaught = ["ios101","android 101","swift 101","database"]
        defaults.set(coursestaught,forKey:"courses")
        //dictionary
        let student = ["name":"prabh","id":"c0654783","program":"madt"]
        defaults.set(student,forKey:"student")
        
        //get specific thing from dictionary
        let x = defaults.double(forKey: "hourlyrate")
        print(x)
        print("is kamal an instructor?")
        print(defaults.bool(forKey: "is instructor"))
        print("what is full name")
        let name  = defaults.string(forKey: "myname")
        print(name!)
        //get an array out
        print("what courses")
        let c = defaults.array(forKey: "courses") as![String]
        print(c)
        //single item
        print(c[0])
        //get dictionary out
        print("who is student")
        let d = defaults.dictionary(forKey: "student") as!Dictionary<String,String>
        print(d)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

